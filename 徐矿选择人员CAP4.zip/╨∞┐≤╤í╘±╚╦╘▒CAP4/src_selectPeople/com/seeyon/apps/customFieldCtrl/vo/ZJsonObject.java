package com.seeyon.apps.customFieldCtrl.vo;

/**
 * 周刘成   2019/5/20
 */
public class ZJsonObject {

    private String field0001;//人员编号
    private String field0003;//部门名称
    private String field0004;//人员姓名
    private String field0006;
    private String zsort;

    public String getZsort() {
        return zsort;
    }

    public void setZsort(String zsort) {
        this.zsort = zsort;
    }

    public String getField0006() {
        return field0006;
    }

    public void setField0006(String field0006) {
        this.field0006 = field0006;
    }

    public String getField0001() {
        return field0001;
    }

    public void setField0001(String field0001) {
        this.field0001 = field0001;
    }

    public String getField0003() {
        return field0003;
    }

    public void setField0003(String field0003) {
        this.field0003 = field0003;
    }

    public String getField0004() {
        return field0004;
    }

    public void setField0004(String field0004) {
        this.field0004 = field0004;
    }
}
