package com.seeyon.apps.customFieldCtrl.vo;

/**
 * 周刘成   2019/5/16
 */
public class People {

    private String deptname;
    private String username;
    private String userid;

    public String getDeptname() {
        return deptname;
    }

    public void setDeptname(String deptname) {
        this.deptname = deptname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }
}
