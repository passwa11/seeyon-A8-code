package com.seeyon.apps.ext.selectPeople.po;

/**
 * 周刘成   2019/5/8
 */
public class Formson0174 {

    private long id;
    private long formmainId;
    private long sort;
    private long field0043;
    private String field0044;
    private String field0045;
    private String field0046;

    public Formson0174() {
    }

    public Formson0174(long id, long formmainId, long sort, long field0043, String field0044, String field0045, String field0046) {
        this.id = id;
        this.formmainId = formmainId;
        this.sort = sort;
        this.field0043 = field0043;
        this.field0044 = field0044;
        this.field0045 = field0045;
        this.field0046 = field0046;
    }

    public long getField0043() {
        return field0043;
    }

    public void setField0043(long field0043) {
        this.field0043 = field0043;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getFormmainId() {
        return formmainId;
    }

    public void setFormmainId(long formmainId) {
        this.formmainId = formmainId;
    }

    public long getSort() {
        return sort;
    }

    public void setSort(long sort) {
        this.sort = sort;
    }



    public String getField0044() {
        return field0044;
    }

    public void setField0044(String field0044) {
        this.field0044 = field0044;
    }

    public String getField0045() {
        return field0045;
    }

    public void setField0045(String field0045) {
        this.field0045 = field0045;
    }

    public String getField0046() {
        return field0046;
    }

    public void setField0046(String field0046) {
        this.field0046 = field0046;
    }
}
