package com.seeyon.apps.ext.kydx.manager;

public interface OrgPostManager {

    void insertPost();

    void updatePost();

    void deletePost();
}
