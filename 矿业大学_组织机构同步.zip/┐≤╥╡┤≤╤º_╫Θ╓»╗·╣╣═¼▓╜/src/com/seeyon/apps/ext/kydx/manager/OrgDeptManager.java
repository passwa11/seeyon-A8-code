package com.seeyon.apps.ext.kydx.manager;


public interface OrgDeptManager {

    void insertOrgDept();

    void insertOtherOrgDept();

    void updateOrgDept();

    void deleteOrgDept();
}
