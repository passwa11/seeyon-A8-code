package com.seeyon.apps.ext.kydx.manager;


public interface OrgLevelManager {

    void insertOrgLevel();

    void updateOrgLevel();

    void deleteOrgLevel();

}
