package com.seeyon.apps.ext.kydx.manager;

public interface OrgMemberManager {

    void insertMember();

    void updateMember();

    void deleteMember();

    void updateLdap();
    void queryDeleteMemberByGh();
}
