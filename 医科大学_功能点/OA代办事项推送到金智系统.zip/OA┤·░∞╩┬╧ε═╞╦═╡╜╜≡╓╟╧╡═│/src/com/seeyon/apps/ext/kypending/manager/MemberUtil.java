package com.seeyon.apps.ext.kypending.manager;

import com.seeyon.ctp.util.JDBCAgent;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

public class MemberUtil {

    public static void main(String[] args) {

    }





}
