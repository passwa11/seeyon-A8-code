package com.seeyon.apps.ext.kypending.util;

public interface ConstantUtil {
    boolean DEBUGGER = true;
}
