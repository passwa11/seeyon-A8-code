create table temp_pending_data(
    id varchar2(40) primary key ,
    preaffairid VARCHAR2(40),
    nextaffairid VARCHAR2(40),
    summaryid varchar2(40),
    prememberid varchar2(40),
    nextmemberid varchar2(40),
    processid varchar2(40)
);