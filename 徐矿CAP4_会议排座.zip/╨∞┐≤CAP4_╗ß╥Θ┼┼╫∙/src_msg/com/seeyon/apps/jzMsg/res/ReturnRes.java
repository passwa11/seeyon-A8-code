package com.seeyon.apps.jzMsg.res;

/**
 * @author Fangaowei
 * <pre>
 * 
 * </pre>
 * @date 2018年10月22日 上午10:39:42
 * @Copyright(c) Beijing Seeyon Software Co.,LTD
 */
public class ReturnRes {
    
    private int status;
    private String msg;
    
    public int getStatus() {
        return status;
    }
    
    public void setStatus(int status) {
        this.status = status;
    }
    
    public String getMsg() {
        return msg;
    }
    
    public void setMsg(String msg) {
        this.msg = msg;
    }
    
    
}
