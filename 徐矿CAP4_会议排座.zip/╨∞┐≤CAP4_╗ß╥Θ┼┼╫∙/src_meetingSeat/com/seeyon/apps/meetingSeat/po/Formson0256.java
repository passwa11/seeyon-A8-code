package com.seeyon.apps.meetingSeat.po;


public class Formson0256 {

	private long id;
	private long formmainId;
	private long sort;
	private long field0008;
	private String field0004;
	private String field0012;
	private String field0025;
	private String field0026;
	private String field0034;
	private String field0035;

	public Formson0256() {
	}

	public Formson0256(long id, long formmainId, long sort, long field0008, String field0004, String field0012,
			String field0025, String field0026, String field0034, String field0035) {
		this.id = id;
		this.formmainId = formmainId;
		this.sort = sort;
		this.field0008 = field0008;
		this.field0004 = field0004;
		this.field0025 = field0025;
		this.field0026 = field0026;
		this.field0034 = field0034;
		this.field0035 = field0035;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getFormmainId() {
		return formmainId;
	}

	public void setFormmainId(long formmainId) {
		this.formmainId = formmainId;
	}

	public long getSort() {
		return sort;
	}

	public void setSort(long sort) {
		this.sort = sort;
	}

	public long getField0008() {
		return field0008;
	}

	public void setField0008(long field0008) {
		this.field0008 = field0008;
	}

	public String getField0004() {
		return field0004;
	}

	public void setField0004(String field0004) {
		this.field0004 = field0004;
	}

	public String getField0012() {
		return field0012;
	}

	public void setField0012(String field0012) {
		this.field0012 = field0012;
	}

	public String getField0025() {
		return field0025;
	}

	public void setField0025(String field0025) {
		this.field0025 = field0025;
	}

	public String getField0026() {
		return field0026;
	}

	public void setField0026(String field0026) {
		this.field0026 = field0026;
	}

	public String getField0034() {
		return field0034;
	}

	public void setField0034(String field0034) {
		this.field0034 = field0034;
	}

	public String getField0035() {
		return field0035;
	}

	public void setField0035(String field0035) {
		this.field0035 = field0035;
	}

}
