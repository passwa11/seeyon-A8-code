package com.seeyon.apps.meetingSeat.po;

public class Formmain0255 {

	private long id;
	private long state;
	private long field0030; // 会议编号

	public Formmain0255() {
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public long getState() {
		return state;
	}

	public void setState(long state) {
		this.state = state;
	}

	public long getField0030() {
		return field0030;
	}

	public void setField0030(long field0030) {
		this.field0030 = field0030;
	}

}
