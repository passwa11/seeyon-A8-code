//package test.com.seeyon.apps.meetingSeat.manager;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import org.junit.jupiter.api.BeforeAll;
//import org.junit.jupiter.api.Test;
//
//import com.seeyon.apps.meetingSeat.manager.MeetingSeatManager;
//import com.seeyon.apps.meetingSeat.manager.MeetingSeatManagerImpl;
//
//class MeetingSeatManagerImplTest {
//
//	private MeetingSeatManager meetingSeatManager = new MeetingSeatManagerImpl();
//
//	@BeforeAll
//	static void setUpBeforeClass() throws Exception {
//	}
//
//	@Test
//	void testHello() {
//		fail("Not yet implemented");
//	}
//
//	@Test
//	void testGetMeetingSeatPersonList() {
//		meetingSeatManager.getMeetingSeatPersonList("HYBH201905004");
//		//fail("Not yet implemented");
//	}
//
//	@Test
//	void testMain() {
//		fail("Not yet implemented");
//	}
//
//}
