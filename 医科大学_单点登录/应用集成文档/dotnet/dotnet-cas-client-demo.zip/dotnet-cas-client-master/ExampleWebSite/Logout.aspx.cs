﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using DotNetCasClient;

public partial class Logout : System.Web.UI.Page
{

    private readonly string idsLogoutUrl = "http://172.16.4.78:9080/logout";
    private readonly string serverName = "http://ssodemo.test.com/cas/Default.aspx";

    protected void Page_Load(object sender, EventArgs e)
    {

        if (CasAuthentication.ServiceTicketManager != null)
        {
            CasAuthentication.SingleSignOut();
        }
        Session.Clear();
        Response.Redirect(idsLogoutUrl + "?service=" + serverName);
        
        ///Response.Redirect("~/Default.aspx");
    }
}