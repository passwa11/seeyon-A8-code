﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;
using System.ComponentModel;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.Schema;

namespace DotNetCasClient.Validation.Schema.Cas20
{
    [Serializable]
    [XmlRoot("attributes")]
    public class Attributes : Dictionary<string, IList<string>>, IXmlSerializable
    {
        internal Attributes() { }
        public XmlSchema GetSchema()
        {
            return null;
        }

        public void ReadXml(XmlReader reader)
        {
            if (reader.IsEmptyElement)
                return;

            while (reader.Read() && reader.NodeType != XmlNodeType.EndElement)
            {
                var key = reader.LocalName;
                var value = reader.ReadString();
                IList<string> list = new List<string>();
                // 如果获取到了值，那么就在取出来的list集合上追加
                if (this.TryGetValue(key, out list))
                {
                    list.Add(value);
                    this.Remove(key);
                    this.Add(key, list);
                }
                else {
                    list = new List<string>();
                    list.Add(value);
                    this.Add(key, list);
                }
                //var list = new List<string>(value.Split(new string[] { "$$" }, StringSplitOptions.RemoveEmptyEntries));
               // this.Add(key, list);
            }
            reader.ReadEndElement();
        }

        public void WriteXml(XmlWriter writer)
        {
            XmlSerializer keySerializer = new XmlSerializer(typeof(string));
            XmlSerializer valueSerializer = new XmlSerializer(typeof(string));
            foreach (string key in this.Keys)
            {
                foreach (var v in this[key])
                {
                    writer.WriteStartElement(key);
                    writer.WriteString(v);
                    writer.WriteEndElement();
                }
                
            }

        }
    }
}
