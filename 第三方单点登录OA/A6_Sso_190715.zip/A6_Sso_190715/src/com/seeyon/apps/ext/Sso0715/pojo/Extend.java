package com.seeyon.apps.ext.Sso0715.pojo;

/**
 * 周刘成   2019/7/17
 */
public class Extend {

    private String name;
    private String value;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}
