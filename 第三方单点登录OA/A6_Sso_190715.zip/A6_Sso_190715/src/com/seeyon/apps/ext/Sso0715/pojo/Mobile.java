package com.seeyon.apps.ext.Sso0715.pojo;

/**
 * 周刘成   2019/7/17
 */
public class Mobile {

    private String type;
    private String number;

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }
}
