package com.seeyon.apps.ext.Sso0715.pojo;

/**
 * 周刘成   2019/7/18
 */
public class Ssoentity {
    private int id;
    private String thirdpart_account;
    private String oa_account;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getThirdpart_account() {
        return thirdpart_account;
    }

    public void setThirdpart_account(String thirdpart_account) {
        this.thirdpart_account = thirdpart_account;
    }

    public String getOa_account() {
        return oa_account;
    }

    public void setOa_account(String oa_account) {
        this.oa_account = oa_account;
    }
}
