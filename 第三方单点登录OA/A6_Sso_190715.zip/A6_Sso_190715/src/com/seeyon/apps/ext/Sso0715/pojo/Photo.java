package com.seeyon.apps.ext.Sso0715.pojo;

/**
 * 周刘成   2019/7/17
 */
public class Photo {

    private String media_id;

    public String getMedia_id() {
        return media_id;
    }

    public void setMedia_id(String media_id) {
        this.media_id = media_id;
    }
}
