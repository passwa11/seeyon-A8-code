create table eh_send_range(
id number primary key not null,
module_id number ,
member_id number,
range_id VARCHAR2(400),
range_name VARCHAR2(400),
spare1 VARCHAR2(400),
spare2 VARCHAR2(400),
spare3 VARCHAR2(400),
spare4 VARCHAR2(400),
spare5 VARCHAR2(400),
spare6 VARCHAR2(400)
);
