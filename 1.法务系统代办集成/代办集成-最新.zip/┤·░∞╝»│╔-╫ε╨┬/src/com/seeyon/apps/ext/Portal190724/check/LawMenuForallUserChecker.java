package com.seeyon.apps.ext.Portal190724.check;

import com.seeyon.ctp.menu.check.MenuCheck;

/**
 * 周刘成   2019-8-12
 */
public class LawMenuForallUserChecker implements MenuCheck {
    @Override
    public boolean check(long l, long l1) {
        return true;
    }
}
