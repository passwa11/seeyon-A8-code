package com.seeyon.apps.ext.Portal190724.po;

/**
 * 周刘成   2019/7/24
 */
public class Result {
    private ResultInfo result;
    private String status;
    private String message;

    public ResultInfo getResultInfo() {
        return result;
    }

    public void setResultInfo(ResultInfo resultInfo) {
        this.result = resultInfo;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
