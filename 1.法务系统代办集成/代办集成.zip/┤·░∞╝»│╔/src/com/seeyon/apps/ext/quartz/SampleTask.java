package com.seeyon.apps.ext.quartz;

import com.seeyon.apps.ext.Portal190724.manager.SyncOrgData;

/**
 * 周刘成   2019/7/26
 */
public class SampleTask implements Runnable {
    @Override
    public void run() {
//        SyncOrgData.getInstance().syncOrgUnit();
//        SyncOrgData.getInstance().syncOrgMember();
    }


}
